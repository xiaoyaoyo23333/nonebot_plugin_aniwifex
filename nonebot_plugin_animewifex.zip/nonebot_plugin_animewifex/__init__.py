"""二次元老婆（NoneBot2 版）

由 AstrBot 插件 `astrbot_plugin_animewifex` 移植而来，业务逻辑、数据格式与
持久化方式保持一致，仅替换框架相关 API：

============================  ==========================================
AstrBot                        NoneBot2
============================  ==========================================
``AstrBotConfig``              ``get_plugin_config(Config)``
``StarTools.get_data_dir``     配置项 ``data_dir`` / NoneBot2 ``data_dir``
``Star`` + ``terminate``       模块导入即初始化 + ``driver.on_shutdown``
``AstrMessageEvent``           ``Event`` / ``Matcher``
``At`` / ``Plain`` / ``Image``  ``MessageSegment.at/text/image``
``filter.event_message_type``  ``on_message`` + 群聊过滤
``event.is_at_or_wake_command``  ``COMMAND_START`` 前缀匹配（``need_prefix``）
============================  ==========================================

注册方式（二者任选）::

    nb-cli plugin install ./nonebot_plugin_animewifex

或把整个目录放进 ``src/plugins/animewifex/`` 后启动 NoneBot2。
"""

from __future__ import annotations

import asyncio
import os
import random
from collections.abc import Awaitable, Callable
from datetime import timedelta, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

# 已停用：远程图床取图所需的网络依赖（本地图库模式不再使用）
# import time
# import aiohttp
from nonebot import get_driver, logger, on_message
from nonebot.adapters import Bot, Event, Message, MessageSegment
from nonebot.matcher import Matcher
from nonebot.rule import Rule

from .config import Config, plugin_config
from .storage import (
    DEFAULT_TIMEZONE,
    get_today,
    has_today_wife,
    load_json,
    migrate_wife_data,
    sanitize_group_records,
    save_json,
    seconds_until_next_midnight,
)

# ==================== 框架适配层 ====================

__all__ = [
    "AnimeWife",
    "Config",
    "anime_wife",
    "anime_wife_matcher",
    "match_command",
    "plugin_config",
]


def _session_type(event: Event) -> str | None:
    """获取会话类型

    NoneBot2 2.5 移除了 ``Event.get_session_type()``，改为直接读取适配器提供的
    ``message_type`` 字段（OneBot V11 / V12 均为 ``group`` / ``private``）；
    旧版本优先走 ``get_session_type()``，都没有时按 ``group_id`` 兜底。
    """
    getter = getattr(event, "get_session_type", None)
    if callable(getter):
        try:
            return str(getter())
        except Exception:
            pass
    message_type = getattr(event, "message_type", None)
    if isinstance(message_type, str):
        return message_type
    if getattr(event, "group_id", None) is not None:
        return "group"
    return None


def _is_group_event(event: Event) -> bool:
    """判断是否为群聊消息事件"""
    return _session_type(event) == "group"


def _bot_self_id(bot: Bot) -> str:
    """机器人自身账号（NoneBot2 2.5 起 Event 不再提供 get_self_id）"""
    return str(getattr(bot, "self_id", "") or "")


def _seg_cls(event: Event) -> type:
    """获取事件使用的消息段类型

    NoneBot2 2.5 起 text()/at()/image() 等工厂方法只存在于各适配器的
    MessageSegment 子类上，核心基类不再提供，这里统一从事件取当前适配器的段类型。
    """
    try:
        return event.get_message().get_segment_class()
    except Exception:
        return MessageSegment


def _event_user_name(event: Event) -> str:
    """获取发送者昵称

    NoneBot2 2.5 移除了 ``Event.get_user_name()``，此处按适配器字段逐级回退：
    OneBot V11 的 ``sender.card`` / ``sender.nickname``，
    OneBot V12 的 ``member.card`` / ``user.display_name``。
    """
    getter = getattr(event, "get_user_name", None)
    if callable(getter):
        try:
            name = getter()
            if name:
                return str(name).strip()
        except Exception:
            pass
    for container_name in ("sender", "member", "user"):
        container = getattr(event, container_name, None)
        if container is None:
            continue
        for key in ("card", "display_name", "nickname", "name"):
            value = getattr(container, key, None)
            if value:
                return str(value).strip()
    for key in ("nickname", "name"):
        value = getattr(event, key, None)
        if value:
            return str(value).strip()
    return ""


def _command_prefixes() -> tuple[str, ...]:
    """读取 NoneBot2 全局命令前缀配置（.env 中的 COMMAND_START）"""
    try:
        raw = get_driver().config.command_start
    except Exception:
        raw = ("/",)
    if isinstance(raw, str):
        raw = (raw,)
    return tuple(str(p) for p in raw if p)


def _extract_text(event: Event) -> str:
    """提取用于命令匹配的消息文本

    ``get_plaintext()`` 会自动剔除 @ 等非文本消息段，因此 ``@机器人 抽老婆``
    与 ``抽老婆`` 等价，AstrBot 版的「唤醒」语义天然保留。

    ``need_prefix`` 开启时要求以 COMMAND_START 中的前缀开头，并去掉该前缀；
    若 COMMAND_START 含空字符串（默认「所有消息都是命令」）则前缀模式不可用。
    """
    try:
        text = event.get_plaintext().strip()
    except Exception:
        return ""
    if not text or not plugin_config.need_prefix:
        return text
    for prefix in _command_prefixes():
        if text.startswith(prefix):
            return text[len(prefix) :].lstrip()
    return ""


def _parse_at_target(event: Event, self_id: str) -> str | None:
    """解析消息中的 @ 目标用户

    跳过所有指向机器人自身的 At，返回第一个有效的目标用户 ID；未找到时返回 None。
    """
    try:
        segments = event.get_message()
    except Exception:
        return None
    for seg in segments:
        if getattr(seg, "type", None) != "at":
            continue
        data = getattr(seg, "data", None)
        if not isinstance(data, dict):
            continue
        uid = data.get("qq") or data.get("user_id")
        if uid is None:
            continue
        uid = str(uid)
        if uid and uid != self_id:
            return uid
    return None


def _build_message(event: Event, segments: list[MessageSegment]) -> Message:
    """用事件自带的消息类组装消息，保证与适配器的类型一致"""
    try:
        message_cls: type[Message] = type(event.get_message())
    except Exception:
        message_cls = Message
    return message_cls(segments)


def _text_seg(event: Event, text: str) -> MessageSegment:
    """构建文本消息段"""
    seg_cls = _seg_cls(event)
    factory = getattr(seg_cls, "text", None)
    if callable(factory):
        try:
            return factory(text)
        except Exception:
            pass
    return seg_cls("text", {"text": text})


def _at_seg(event: Event, user_id: str) -> MessageSegment:
    """构建 @ 消息段"""
    seg_cls = _seg_cls(event)
    factory = getattr(seg_cls, "at", None)
    if callable(factory):
        try:
            return factory(user_id)
        except Exception:
            pass
    return seg_cls("at", {"qq": str(user_id)})


def _image_seg(
    event: Event, *, file: str | None = None, url: str | None = None
) -> MessageSegment:
    """构建图片消息段（本地文件优先用适配器的 image()，远程链接走 url 字段）"""
    seg_cls = _seg_cls(event)
    if file:
        factory = getattr(seg_cls, "image", None)
        if callable(factory):
            try:
                return factory(file)
            except Exception:
                pass
        return seg_cls("image", {"file": str(file)})
    return seg_cls("image", {"url": url})


async def _group_ban(bot: Any, gid: str, uid: str, duration: int) -> bool:
    """禁言，兼容 OneBot V11 / V12 及其他适配器的调用方式"""
    try:
        kwargs = {"group_id": int(gid), "user_id": int(uid), "duration": duration}
    except (TypeError, ValueError):
        return False
    try:
        await bot.set_group_ban(**kwargs)
        return True
    except Exception:
        pass
    for api in ("set_group_ban", "group_ban"):
        try:
            await bot.call_api(api, **kwargs)
            return True
        except Exception:
            continue
    return False


# ==================== 主插件逻辑 ====================


class AnimeWife:
    """二次元老婆插件主类（原 AstrBot ``WifePlugin``）"""

    def __init__(self) -> None:
        self._init_config()
        self._init_commands()
        self._init_storage()
        self._daily_cleanup_task: asyncio.Task | None = None

    # ==================== 初始化 ====================

    def _init_config(self) -> None:
        """初始化配置参数（带默认值兜底，避免配置缺项导致加载失败）"""
        self.tz = self._resolve_timezone()
        # 配置里写数字型 ID 也统一转成字符串比较
        self.admins = {str(a) for a in plugin_config.admins}
        self.need_prefix = bool(plugin_config.need_prefix)
        self.ntr_max = plugin_config.ntr_max
        self.ntr_possibility = plugin_config.ntr_possibility
        self.change_max_per_day = plugin_config.change_max_per_day
        self.swap_max_per_day = plugin_config.swap_max_per_day
        self.reset_max_uses_per_day = plugin_config.reset_max_uses_per_day
        self.reset_success_rate = plugin_config.reset_success_rate
        self.reset_mute_duration = plugin_config.reset_mute_duration

        # ---- 已停用：远程图床配置（本地图库模式不再需要）----
        # base_url = plugin_config.image_base_url or "https://cdn.jsdmirror.com/gh/monbed/wife@main"
        # self.image_base_url = base_url.rstrip("/") + "/"
        # self.image_list_url = (
        #     plugin_config.image_list_url or "https://animewife.dpdns.org/list.txt"
        # )

    def _resolve_timezone(self) -> ZoneInfo:
        """解析判定「今天」所用的时区

        优先级：``ANIMEWIFEX_TIMEZONE`` > NoneBot2 全局 ``timezone`` > 环境变量 ``TZ``
        > ``Asia/Shanghai``。

        Windows 的 Python 默认不带 IANA 时区库（NoneBot2 也不依赖 ``tzdata``），
        此时 ``ZoneInfo`` 会抛 ``ZoneInfoNotFoundError``；这里逐个候选尝试，
        全部失败后退回固定 UTC+8，保证插件始终能正常加载，不会因缺少可选依赖而崩溃。
        """
        candidates: list[str] = []
        tz_name = str(plugin_config.timezone or "").strip()
        if tz_name:
            candidates.append(tz_name)
        try:
            global_tz = str(getattr(get_driver().config, "timezone", "") or "").strip()
        except Exception:
            global_tz = ""
        if global_tz:
            candidates.append(global_tz)
        env_tz = os.environ.get("TZ", "").strip()
        if env_tz:
            candidates.append(env_tz)
        candidates.append(DEFAULT_TIMEZONE)

        for name in candidates:
            try:
                return ZoneInfo(name)
            except Exception:
                logger.error(f"时区 {name!r} 不可用，尝试下一个回退值")

        # 连 tzdata 都没装时的最终兜底：东八区固定偏移
        logger.warning(
            "未找到可用的 IANA 时区数据（是否缺少 tzdata？），已回退固定 UTC+8"
        )
        return timezone(timedelta(hours=8))  # type: ignore[return-value]

    def _resolve_data_dir(self) -> Path:
        """插件数据目录

        优先 ``ANIMEWIFEX_DATA_DIR``；其次 NoneBot2 全局 ``data_dir/animewifex``；
        全局也未配置时退回项目目录下约定俗成的 ``data/animewifex``。
        """
        raw = str(plugin_config.data_dir or "").strip()
        if raw:
            path = Path(raw).expanduser()
            return path if path.is_absolute() else Path.cwd() / path
        try:
            base = str(getattr(get_driver().config, "data_dir", "") or "").strip()
        except Exception:
            base = ""
        if not base:
            base = "data"  # NoneBot2 历史默认的数据目录
        path = Path(base).expanduser()
        if not path.is_absolute():
            path = Path.cwd() / path
        return path / "animewifex"

    def _init_commands(self) -> None:
        """初始化命令映射表"""
        self.commands: dict[str, Callable[[Event, Bot, Matcher], Awaitable[None]]] = {
            "老婆帮助": self.wife_help,
            "抽老婆": self.animewife,
            "查老婆": self.search_wife,
            "牛老婆": self.ntr_wife,
            "重置牛": self.reset_ntr,
            "重置换": self.reset_change_wife,
            "切换ntr开关状态": self.switch_ntr,
            "切换NTR开关状态": self.switch_ntr,
            "换老婆": self.change_wife,
            "交换老婆": self.swap_wife,
            "同意交换": self.agree_swap_wife,
            "拒绝交换": self.reject_swap_wife,
            "查看交换请求": self.view_swap_requests,
        }
        # 按命令名长度降序排列，匹配时避免较短的命令意外截胡更长的命令
        self.command_names = sorted(self.commands, key=len, reverse=True)

    def _init_storage(self) -> None:
        """初始化数据目录并加载持久化数据"""
        plugin_dir = self._resolve_data_dir()
        self.config_dir = plugin_dir / "config"
        self.img_dir = plugin_dir / "img" / "wife"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.img_dir.mkdir(parents=True, exist_ok=True)

        self.records_file = self.config_dir / "records.json"
        self.swap_requests_file = self.config_dir / "swap_requests.json"
        self.ntr_status_file = self.config_dir / "ntr_status.json"
        # 已停用：远程图片列表缓存（本地图库模式不再需要）
        # self.wife_list_cache_file = self.config_dir / "wife_list_cache.txt"

        # 群组级状态锁：保护该群的配置、各类次数记录与交换请求
        self.group_locks: dict[str, asyncio.Lock] = {}

        raw = load_json(self.records_file)
        # ntr=牛老婆次数 change=换老婆次数 reset=重置机会次数 swap=交换请求次数
        self.records = {
            key: sanitize_group_records(raw.get(key), f"records.json[{key}]")
            for key in ("ntr", "change", "reset", "swap")
        }
        # 启动阶段尚无并发，清理无需加锁；校验丢弃过非法条目时同样需要落盘
        today = get_today(self.tz)
        changed = any(self.records[key] != raw.get(key, {}) for key in self.records)
        for gid in {gid for recs in self.records.values() for gid in recs}:
            changed |= self._prune_group_records(gid, today)
        if changed:
            self.save_records()
        self.swap_requests = self._load_swap_requests()
        self.ntr_statuses = load_json(self.ntr_status_file)

    # ==================== 并发与持久化 ====================

    def get_group_lock(self, group_id: str) -> asyncio.Lock:
        """获取或创建群组级状态锁"""
        if group_id not in self.group_locks:
            self.group_locks[group_id] = asyncio.Lock()
        return self.group_locks[group_id]

    def save_records(self) -> None:
        save_json(self.records_file, self.records)

    def _prune_group_records(self, gid: str, today: str) -> bool:
        """删除某群各类别中日期不是今天的次数记录，群内清空后移除该群条目，返回是否有变动

        处理协程可能在群锁内持有群记录字典的引用跨越 await 点，
        运行期调用必须先持有该群的锁，避免删除群条目后协程写入悬空字典。
        """
        changed = False
        for recs in self.records.values():
            grp = recs.get(gid)
            if grp is None:
                continue
            stale = [uid for uid, rec in grp.items() if rec.get("date") != today]
            for uid in stale:
                del grp[uid]
            if stale or not grp:
                changed = True
            if not grp:
                del recs[gid]
        return changed

    def _load_swap_requests(self) -> dict:
        """加载交换请求，过滤结构非法的条目并清理过期数据"""
        raw = load_json(self.swap_requests_file)
        sanitized = sanitize_group_records(raw, "swap_requests.json")
        today = get_today(self.tz)
        cleaned = {}
        for gid, reqs in sanitized.items():
            valid = {uid: rec for uid, rec in reqs.items() if rec.get("date") == today}
            if valid:
                cleaned[gid] = valid
        if raw != cleaned:
            save_json(self.swap_requests_file, cleaned)
        return cleaned

    def save_swap_requests(self) -> None:
        save_json(self.swap_requests_file, self.swap_requests)

    def save_ntr_statuses(self) -> None:
        save_json(self.ntr_status_file, self.ntr_statuses)

    def load_group_config(self, group_id: str) -> dict:
        """加载群组配置，旧版列表格式的老婆数据自动迁移为字典，无法识别的条目丢弃"""
        raw = load_json(self.config_dir / f"{group_id}.json")
        cfg = {}
        for uid, data in raw.items():
            wife = migrate_wife_data(data)
            if wife is not None:
                cfg[uid] = wife
        return cfg

    def save_group_config(self, group_id: str, cfg: dict) -> None:
        save_json(self.config_dir / f"{group_id}.json", cfg)

    # ==================== 通用辅助 ====================

    @staticmethod
    def _uid(event: Event) -> str:
        return str(event.get_user_id())

    @staticmethod
    def _gid(event: Event) -> str:
        return str(getattr(event, "group_id"))

    @staticmethod
    def _nick(event: Event) -> str:
        return _event_user_name(event) or str(event.get_user_id())

    def _is_admin(self, uid: str) -> bool:
        """插件 admins 配置 + NoneBot2 SUPERUSERS 共同构成管理员"""
        if uid in self.admins:
            return True
        try:
            return uid in {str(s) for s in get_driver().config.superusers}
        except Exception:
            return False

    async def _send_all(self, matcher: Matcher, replies: list[Any]) -> None:
        """依次发送收集好的回复"""
        for reply in replies:
            await matcher.send(reply)

    # ==================== 目标解析 ====================

    def parse_target(self, event: Event, text: str, bot: Bot) -> str | None:
        """解析命令目标用户：优先 @ ，其次「查老婆 昵称」形式的昵称匹配"""
        target = _parse_at_target(event, _bot_self_id(bot))
        if target:
            return target

        if text.startswith("牛老婆") or text.startswith("查老婆"):
            parts = text.split(maxsplit=1)
            if len(parts) > 1:
                name = parts[1]
                cfg = self.load_group_config(self._gid(event))
                for uid, wife in cfg.items():
                    if wife.get("owner") == name:
                        return uid
        return None

    # ==================== 抽老婆与查询 ====================

    async def animewife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """抽老婆"""
        gid = self._gid(event)
        uid = self._uid(event)
        nick = self._nick(event)
        today = get_today(self.tz)

        async with self.get_group_lock(gid):
            cfg = self.load_group_config(gid)
            if not has_today_wife(cfg, uid, today):
                img = await self._fetch_wife_image()
                if img:
                    cfg[uid] = {"img": img, "date": today, "owner": nick}
                    self.save_group_config(gid, cfg)
            else:
                img = cfg[uid]["img"]

        if not img:
            await matcher.finish("抱歉，今天的老婆获取失败了，请稍后再试~")
        await matcher.finish(self._build_wife_message(event, img, nick))

    async def search_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """查老婆"""
        gid = self._gid(event)
        text = _extract_text(event)
        tid = self.parse_target(event, text, bot) or self._uid(event)
        today = get_today(self.tz)

        cfg = self.load_group_config(gid)

        if not has_today_wife(cfg, tid, today):
            await matcher.finish("没有发现老婆的踪迹，快去抽一个试试吧~")

        img = cfg[tid]["img"]
        owner = cfg[tid].get("owner", "未知用户")
        chara, source = self._parse_wife_name(img)
        if source:
            text_out = f"{owner}的老婆是来自《{source}》的{chara}，羡慕吗？"
        else:
            text_out = f"{owner}的老婆是{chara}，羡慕吗？"
        await matcher.finish(self._build_chain(event, text_out, img))

    async def _fetch_wife_image(self) -> str | None:
        """从本地图库随机抽取一张图片

        现为**纯本地模式**：只扫描 <数据目录>/img/wife/ 下的文件，不做任何网络请求。
        图库为空时返回 None，由调用方给出「获取失败」的提示。
        """
        try:
            with os.scandir(self.img_dir) as entries:
                local_imgs = [e.name for e in entries if e.is_file()]
            if local_imgs:
                return random.choice(local_imgs)
        except OSError:
            pass

        logger.warning(
            f"本地图库为空或不可读，请在 {self.img_dir} 放入图片后再试"
        )
        return None

        # ------------------------------------------------------------------
        # 以下为已停用的「远程图床」取图逻辑（依赖 image_list_url + 网络列表缓存）。
        # 如需恢复：还原本段、_init_config 中的 image_list_url 配置、
        # _build_image_segment 中的 URL 回退分支，以及 aiohttp / time 导入。
        # ------------------------------------------------------------------
        # cached_lines: list[str] = []
        # cache_expired = True
        # if self.wife_list_cache_file.exists():
        #     try:
        #         cache_expired = (
        #             time.time() - self.wife_list_cache_file.stat().st_mtime
        #         ) >= 3600
        #         with open(self.wife_list_cache_file, "r", encoding="utf-8") as f:
        #             cached_lines = [
        #                 s for s in (line.strip() for line in f.read().splitlines()) if s
        #             ]
        #     except (OSError, UnicodeDecodeError):
        #         pass
        #
        # if not cache_expired and cached_lines:
        #     return random.choice(cached_lines)
        #
        # try:
        #     timeout = aiohttp.ClientTimeout(total=10)
        #     async with aiohttp.ClientSession(timeout=timeout) as session:
        #         async with session.get(self.image_list_url) as resp:
        #             if resp.status == 200:
        #                 text = await resp.text()
        #                 lines = [
        #                     s for s in (line.strip() for line in text.splitlines()) if s
        #                 ]
        #                 if lines:
        #                     try:
        #                         with open(
        #                             self.wife_list_cache_file, "w", encoding="utf-8"
        #                         ) as f:
        #                             f.write("\n".join(lines))
        #                     except OSError:
        #                         pass
        #                     return random.choice(lines)
        # except Exception:
        #     pass
        #
        # if cached_lines:
        #     return random.choice(cached_lines)
        # return None

    @staticmethod
    def _parse_wife_name(img: str) -> tuple[str, str | None]:
        """从图片标识解析出 (角色名, 作品来源)，无来源时来源为 None"""
        name = os.path.splitext(img)[0].split("/")[-1]
        if "!" in name:
            source, chara = name.split("!", 1)
            return chara, source
        return name, None

    def _build_image_segment(self, event: Event, img: str) -> MessageSegment | None:
        """根据图片标识构建图片消息段（仅本地图库）"""
        # 图片标识来自群配置，读取前校验路径未逃逸出图库目录
        try:
            base = os.path.abspath(self.img_dir)
            path = os.path.abspath(os.path.join(base, img))
            # Windows 下跨盘符会让 commonpath 抛 ValueError，按「不在图库内」处理
            if os.path.commonpath([base, path]) == base and os.path.isfile(path):
                return _image_seg(event, file=path)
        except (ValueError, OSError):
            pass

        logger.warning(f"本地图库中找不到图片，已跳过：{img}")
        return None

        # 已停用的远程 URL 回退分支，如需恢复见 _fetch_wife_image 的说明
        # try:
        #     return _image_seg(event, url=self.image_base_url + img)
        # except Exception:
        #     logger.exception("构建图片消息段失败")
        #     return None

    def _build_chain(self, event: Event, text: str, img: str) -> Message:
        """构建「文字 + 图片」消息，图片段构建失败时仅保留文字"""
        parts = [_text_seg(event, text)]
        img_seg = self._build_image_segment(event, img)
        if img_seg is not None:
            parts.append(img_seg)
        return _build_message(event, parts)

    def _build_wife_message(self, event: Event, img: str, nick: str) -> Message:
        """构建「你今天的老婆是…」消息"""
        chara, source = self._parse_wife_name(img)
        if source:
            text = f"{nick}，你今天的老婆是来自《{source}》的{chara}，请好好珍惜哦~"
        else:
            text = f"{nick}，你今天的老婆是{chara}，请好好珍惜哦~"
        return self._build_chain(event, text, img)

    # ==================== 帮助命令 ====================

    async def wife_help(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """显示帮助信息"""
        help_text = """
【基础命令】
• 抽老婆 - 每天抽取一个二次元老婆
• 查老婆 [@用户] - 查看别人的老婆

【牛老婆功能】(概率较低😭)
• 牛老婆 [@用户] - 有概率抢走别人的老婆
• 重置牛 [@用户] - 重置牛的次数(失败会禁言)

【换老婆功能】
• 换老婆 - 丢弃当前老婆换新的
• 重置换 [@用户] - 重置换老婆的次数(失败会禁言)

【交换功能】
• 交换老婆 [@用户] - 向别人发起老婆交换请求
• 同意交换 [@发起者] - 同意交换请求
• 拒绝交换 [@发起者] - 拒绝交换请求
• 查看交换请求 - 查看当前的交换请求

【管理员命令】
• 切换ntr开关状态 - 开启/关闭NTR功能

💡 提示：部分命令有每日使用次数限制
"""
        await matcher.finish(help_text.strip())

    # ==================== 牛老婆相关 ====================

    async def ntr_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """牛老婆"""
        gid = self._gid(event)
        uid = self._uid(event)
        nick = self._nick(event)
        today = get_today(self.tz)
        text = _extract_text(event)

        tid = self.parse_target(event, text, bot)

        # 锁内只收集回复、出锁后统一发送，避免持锁等待消息发送
        replies: list[Any] = []
        async with self.get_group_lock(gid):
            grp = self.records["ntr"].setdefault(gid, {})
            rec = grp.get(uid, {"date": today, "count": 0})
            if rec["date"] != today:
                rec = {"date": today, "count": 0}

            cfg = self.load_group_config(gid)
            if not self.ntr_statuses.get(gid, True):
                replies.append("牛老婆功能还没开启哦，请联系管理员开启~")
            elif not tid or tid == uid:
                msg = (
                    "请@你想牛的对象，或输入完整的昵称哦~"
                    if not tid
                    else "不能牛自己呀，换个人试试吧~"
                )
                replies.append(f"{nick}，{msg}")
            elif rec["count"] >= self.ntr_max:
                replies.append(f"{nick}，你今天已经牛了{self.ntr_max}次啦，明天再来吧~")
            elif not has_today_wife(cfg, tid, today):
                replies.append("对方今天还没有老婆可牛哦~")
            else:
                rec["count"] += 1
                grp[uid] = rec
                self.save_records()

                if random.random() < self.ntr_possibility:
                    img = cfg[tid]["img"]
                    cfg[uid] = {"img": img, "date": today, "owner": nick}
                    del cfg[tid]
                    self.save_group_config(gid, cfg)
                    cancel_msg = self.cancel_swap_on_wife_change(gid, [uid, tid])

                    replies.append(f"{nick}，牛老婆成功！老婆已归你所有，恭喜恭喜~")
                    if cancel_msg:
                        replies.append(cancel_msg)
                    replies.append(self._build_wife_message(event, img, nick))
                else:
                    remaining = self.ntr_max - rec["count"]
                    replies.append(
                        f"{nick}，很遗憾，牛失败了！你今天还可以再试{remaining}次~"
                    )

        await self._send_all(matcher, replies)

    async def switch_ntr(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """切换 NTR 开关（仅管理员）"""
        uid = self._uid(event)
        nick = self._nick(event)

        if not self._is_admin(uid):
            await matcher.finish(f"{nick}，你没有权限操作哦~")

        gid = self._gid(event)
        async with self.get_group_lock(gid):
            new_status = not self.ntr_statuses.get(gid, True)
            self.ntr_statuses[gid] = new_status
            self.save_ntr_statuses()

        state = "开启" if new_status else "关闭"
        await matcher.finish(f"{nick}，NTR已{state}")

    # ==================== 换老婆相关 ====================

    async def change_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """换老婆"""
        gid = self._gid(event)
        uid = self._uid(event)
        nick = self._nick(event)
        today = get_today(self.tz)

        replies: list[Any] = []
        # 次数检查、自增与更换老婆在同一临界区内完成，避免并发绕过每日上限
        async with self.get_group_lock(gid):
            recs = self.records["change"].setdefault(gid, {})
            rec = recs.get(uid, {"date": "", "count": 0})

            cfg = self.load_group_config(gid)
            if rec["date"] == today and rec["count"] >= self.change_max_per_day:
                replies.append(
                    f"{nick}，你今天已经换了{self.change_max_per_day}次老婆啦，明天再来吧~"
                )
            elif not has_today_wife(cfg, uid, today):
                replies.append(f"{nick}，你今天还没有老婆，先去抽一个再来换吧~")
            else:
                # 先抽到新老婆再替换；抽取失败时老婆和次数都保持不动
                img = await self._fetch_wife_image()
                if not img:
                    replies.append(
                        "抱歉，新老婆获取失败了，本次更换未生效，请稍后再试~"
                    )
                else:
                    cfg[uid] = {"img": img, "date": today, "owner": nick}
                    self.save_group_config(gid, cfg)

                    if rec["date"] != today:
                        rec = {"date": today, "count": 1}
                    else:
                        rec["count"] += 1
                    recs[uid] = rec
                    self.save_records()

                    cancel_msg = self.cancel_swap_on_wife_change(gid, [uid])
                    if cancel_msg:
                        replies.append(cancel_msg)
                    replies.append(self._build_wife_message(event, img, nick))

        await self._send_all(matcher, replies)

    # ==================== 重置相关 ====================

    async def _do_reset(
        self,
        event: Event,
        bot: Bot,
        matcher: Matcher,
        category: str,
        label: str,
        short: str,
    ) -> None:
        """通用重置逻辑

        category: records 中要被重置的类别键（"ntr" / "change"）
        label:    消息中的完整名称（如 "牛老婆"）
        short:    失败提示中的简称（如 "牛"）
        """
        gid = self._gid(event)
        uid = self._uid(event)
        nick = self._nick(event)
        today = get_today(self.tz)
        tid = _parse_at_target(event, _bot_self_id(bot)) or uid

        if self._is_admin(uid):
            async with self.get_group_lock(gid):
                grp = self.records[category].setdefault(gid, {})
                if tid in grp:
                    del grp[tid]
                    self.save_records()
            await matcher.finish(
                _build_message(
                    event,
                    [
                        _text_seg(event, "管理员操作：已重置"),
                        _at_seg(event, tid),
                        _text_seg(event, f"的{label}次数。"),
                    ],
                )
            )

        # 限额检查与自增在同一临界区内完成
        replies: list[Any] = []
        do_ban = False
        async with self.get_group_lock(gid):
            grp_reset = self.records["reset"].setdefault(gid, {})
            rec = grp_reset.get(uid, {"date": today, "count": 0})
            if rec.get("date") != today:
                rec = {"date": today, "count": 0}

            if rec["count"] >= self.reset_max_uses_per_day:
                replies.append(
                    f"{nick}，你今天已经用完{self.reset_max_uses_per_day}次重置机会啦，明天再来吧~"
                )
            else:
                rec["count"] += 1
                grp_reset[uid] = rec

                if random.random() < self.reset_success_rate:
                    self.records[category].setdefault(gid, {}).pop(tid, None)
                    replies.append(
                        _build_message(
                            event,
                            [
                                _text_seg(event, "已重置"),
                                _at_seg(event, tid),
                                _text_seg(event, f"的{label}次数。"),
                            ],
                        )
                    )
                else:
                    do_ban = True
                    replies.append(
                        f"{nick}，重置{short}失败，被禁言{self.reset_mute_duration}秒，下次记得再接再厉哦~"
                    )

                # 自增与可能的删除合并为一次落盘
                self.save_records()

        if do_ban:
            try:
                await _group_ban(bot, gid, uid, self.reset_mute_duration)
            except Exception:
                logger.exception("禁言失败")

        await self._send_all(matcher, replies)

    async def reset_ntr(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """重置牛老婆次数"""
        await self._do_reset(event, bot, matcher, "ntr", "牛老婆", "牛")

    async def reset_change_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """重置换老婆次数"""
        await self._do_reset(event, bot, matcher, "change", "换老婆", "换")

    # ==================== 交换老婆相关 ====================

    async def swap_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """发起交换老婆请求"""
        gid = self._gid(event)
        uid = self._uid(event)
        tid = _parse_at_target(event, _bot_self_id(bot))
        nick = self._nick(event)
        today = get_today(self.tz)

        replies: list[Any] = []
        # 次数检查、自增与请求记录在同一临界区内完成
        async with self.get_group_lock(gid):
            grp_limit = self.records["swap"].setdefault(gid, {})
            rec_lim = grp_limit.get(uid, {"date": "", "count": 0})
            if rec_lim["date"] != today:
                rec_lim = {"date": today, "count": 0}

            # 已有待处理请求时重复发起视为更换目标：旧请求取消、今天消耗的次数返还，
            # 因此限额按返还后的值校验，保证换目标不被当日上限挡住
            old_req = self.swap_requests.get(gid, {}).get(uid)
            refundable = (
                1
                if old_req and old_req.get("date") == today and rec_lim["count"] > 0
                else 0
            )

            if rec_lim["count"] - refundable >= self.swap_max_per_day:
                replies.append(
                    f"{nick}，你今天已经发起了{self.swap_max_per_day}次交换请求啦，明天再来吧~"
                )
            elif not tid or tid == uid:
                # 次数未用完，再校验是否@了交换对象（保持原版校验顺序）
                replies.append(f"{nick}，请在命令后@你想交换的对象哦~")
            else:
                cfg = self.load_group_config(gid)
                no_wife_who = None
                for x in (uid, tid):
                    if not has_today_wife(cfg, x, today):
                        no_wife_who = nick if x == uid else "对方"
                        break

                if no_wife_who:
                    replies.append(f"{no_wife_who}，今天还没有老婆，无法进行交换哦~")
                else:
                    cancel_note = None
                    if old_req is not None:
                        rec_lim["count"] -= refundable
                        cancel_note = (
                            "已自动取消你之前发起的交换请求并返还次数~"
                            if refundable
                            else "已自动取消你之前发起的交换请求~"
                        )

                    rec_lim["count"] += 1
                    grp_limit[uid] = rec_lim
                    self.save_records()

                    self.swap_requests.setdefault(gid, {})[uid] = {
                        "target": tid,
                        "date": today,
                    }
                    self.save_swap_requests()

                    if cancel_note:
                        replies.append(cancel_note)
                    replies.append(
                        _build_message(
                            event,
                            [
                                _text_seg(event, f"{nick} 想和 "),
                                _at_seg(event, tid),
                                _text_seg(
                                    event,
                                    ' 交换老婆啦！请对方用"同意交换 @发起者"或"拒绝交换 @发起者"来回应~',
                                ),
                            ],
                        )
                    )

        await self._send_all(matcher, replies)

    async def agree_swap_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """同意交换老婆"""
        gid = self._gid(event)
        tid = self._uid(event)
        uid = _parse_at_target(event, _bot_self_id(bot))
        nick = self._nick(event)
        today = get_today(self.tz)

        replies: list[Any] = []
        async with self.get_group_lock(gid):
            grp = self.swap_requests.get(gid, {})
            rec = grp.get(uid)

            if rec and rec.get("date") != today:
                # 跨天后的陈旧请求视为已过期（定时清理在每日零点执行，此处兜底）
                del grp[uid]
                self.save_swap_requests()
                replies.append("该交换请求已过期，请重新发起交换吧~")
            elif not rec or rec.get("target") != tid:
                replies.append(
                    f'{nick}，请在命令后@发起者，或用"查看交换请求"命令查看当前请求哦~'
                )
            else:
                cfg = self.load_group_config(gid)
                # 兜底校验：插件内的老婆变动会同步取消请求，但配置文件被外部修改或损坏时，
                # 请求可能仍指向已不存在的老婆，直接交换会抛 KeyError，这里转为友好失败
                if not has_today_wife(cfg, uid, today) or not has_today_wife(
                    cfg, tid, today
                ):
                    del grp[uid]
                    self.save_swap_requests()
                    replies.append(
                        "交换失败，有一方的老婆已经发生变化，请重新发起交换吧~"
                    )
                else:
                    # 仅交换图片标识，各自保留昵称与日期
                    cfg[uid]["img"], cfg[tid]["img"] = cfg[tid]["img"], cfg[uid]["img"]
                    self.save_group_config(gid, cfg)

                    del grp[uid]
                    self.save_swap_requests()

                    cancel_msg = self.cancel_swap_on_wife_change(gid, [uid, tid])

                    replies.append("交换成功！你们的老婆已经互换啦，祝幸福~")
                    if cancel_msg:
                        replies.append(cancel_msg)

        await self._send_all(matcher, replies)

    async def reject_swap_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """拒绝交换老婆"""
        gid = self._gid(event)
        tid = self._uid(event)
        uid = _parse_at_target(event, _bot_self_id(bot))
        nick = self._nick(event)
        today = get_today(self.tz)

        replies: list[Any] = []
        async with self.get_group_lock(gid):
            grp = self.swap_requests.get(gid, {})
            rec = grp.get(uid)

            if rec and rec.get("date") != today:
                # 跨天后的陈旧请求视为已过期（定时清理在每日零点执行，此处兜底）
                del grp[uid]
                self.save_swap_requests()
                replies.append("该交换请求已过期，无需拒绝啦~")
            elif not rec or rec.get("target") != tid:
                replies.append(
                    f'{nick}，请在命令后@发起者，或用"查看交换请求"命令查看当前请求哦~'
                )
            else:
                del grp[uid]
                self.save_swap_requests()
                replies.append(
                    _build_message(
                        event,
                        [
                            _at_seg(event, uid),
                            _text_seg(event, "，对方婉拒了你的交换请求，下次加油吧~"),
                        ],
                    )
                )

        await self._send_all(matcher, replies)

    async def view_swap_requests(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """查看当前交换请求"""
        gid = self._gid(event)
        me = self._uid(event)
        today = get_today(self.tz)

        grp = {
            uid: rec
            for uid, rec in self.swap_requests.get(gid, {}).items()
            if rec.get("date") == today
        }
        cfg = self.load_group_config(gid)

        my_req = grp.get(me)
        my_target = my_req.get("target") if my_req else None
        sent_targets = [my_target] if my_target else []
        received_from = [uid for uid, rec in grp.items() if rec.get("target") == me]

        if not sent_targets and not received_from:
            await matcher.finish("你当前没有任何交换请求哦~")

        parts = []
        for tid in sent_targets:
            name = (cfg.get(tid) or {}).get("owner", "未知用户")
            parts.append(f"→ 你发起给 {name} 的交换请求")

        for uid in received_from:
            name = (cfg.get(uid) or {}).get("owner", "未知用户")
            parts.append(f"→ {name} 发起给你的交换请求")

        text_out = (
            "当前交换请求如下：\n"
            + "\n".join(parts)
            + '\n请在"同意交换"或"拒绝交换"命令后@发起者进行操作~'
        )
        await matcher.finish(text_out)

    def cancel_swap_on_wife_change(self, gid: str, user_ids: list) -> str | None:
        """老婆发生变动时，取消相关的交换请求并返还发起次数（需在群锁内调用）"""
        today = get_today(self.tz)
        grp = self.swap_requests.get(gid, {})
        grp_limit = self.records["swap"].setdefault(gid, {})

        # 只取消今天的活请求；昨日的死请求交给过期机制（兜底提示 + 零点清理），
        # 避免零点后清理前的窗口期把已过期请求误报为"因老婆变动取消"
        to_cancel = [
            req_uid
            for req_uid, req in grp.items()
            if req.get("date") == today
            and (req_uid in user_ids or req.get("target") in user_ids)
        ]

        if not to_cancel:
            return None

        for req_uid in to_cancel:
            rec_lim = grp_limit.get(req_uid, {"date": "", "count": 0})
            if rec_lim.get("date") == today and rec_lim.get("count", 0) > 0:
                rec_lim["count"] = max(0, rec_lim["count"] - 1)
                grp_limit[req_uid] = rec_lim
            del grp[req_uid]

        self.save_swap_requests()
        self.save_records()

        return f"已自动取消 {len(to_cancel)} 条相关的交换请求并返还次数~"

    # ==================== 定时清理 ====================

    async def _daily_cleanup_loop(self) -> None:
        """每天零点清理跨天失效的数据：过期交换请求与历史次数记录"""
        while True:
            try:
                # 多等一分钟，避免时钟误差导致在日期变更前执行
                await asyncio.sleep(seconds_until_next_midnight(self.tz) + 60)
                await self._cleanup_expired_swap_requests()
                await self._cleanup_expired_records()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("定时清理过期数据失败")

    async def _cleanup_expired_swap_requests(self) -> None:
        """逐群清理日期不是今天的交换请求"""
        today = get_today(self.tz)
        for gid in list(self.swap_requests.keys()):
            async with self.get_group_lock(gid):
                reqs = self.swap_requests.get(gid, {})
                expired = [uid for uid, rec in reqs.items() if rec.get("date") != today]
                for uid in expired:
                    del reqs[uid]
                if not reqs:
                    self.swap_requests.pop(gid, None)
                if expired:
                    self.save_swap_requests()

    async def _cleanup_expired_records(self) -> None:
        """逐群清理历史次数记录（在群锁内执行，避免与处理协程交错）"""
        today = get_today(self.tz)
        changed = False
        for gid in {gid for recs in self.records.values() for gid in recs}:
            async with self.get_group_lock(gid):
                if self._prune_group_records(gid, today):
                    changed = True
        if changed:
            self.save_records()

    def start(self) -> None:
        """插件加载后启动零点清理任务"""
        if self._daily_cleanup_task and not self._daily_cleanup_task.done():
            return
        coro = self._daily_cleanup_loop()
        try:
            self._daily_cleanup_task = asyncio.create_task(coro)
        except RuntimeError:
            # 无运行中的事件循环时关闭协程，避免 "coroutine never awaited" 告警
            coro.close()
            self._daily_cleanup_task = None

    async def shutdown(self) -> None:
        """NoneBot2 关闭 / 插件卸载时停止后台任务（对应 AstrBot 的 terminate）"""
        task = self._daily_cleanup_task
        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass


# ==================== 插件注册 ====================

anime_wife = AnimeWife()


def match_command(event: Event) -> str | None:
    """返回消息命中的本插件命令名，未命中返回 None

    **严格匹配**：整条消息必须恰好等于命令名，或为「命令名 + 空格 + 参数」。
    这样「帮我换老婆」「换老婆啊」「xxxx换老婆xxxx」都不会误触发；
    而「查老婆 明日香」「牛老婆 @某人」这类带参数的正常用法仍然可用。

    同时供匹配规则与处理函数使用，避免两处判定逻辑走偏。
    """
    if not _is_group_event(event):
        return None
    text = _extract_text(event)
    if not text:
        return None
    for cmd in anime_wife.command_names:
        if text == cmd or text.startswith(f"{cmd} "):
            return cmd
    return None


def _trigger_rule(event: Event) -> bool:
    """只在群聊、且消息严格等于本插件命令时触发

    配合 ``block=False``（默认）实现「各答各的」：本插件答完自己的二次元老婆后
    放行事件，其它老婆插件（如抽群友的 today_waifu）仍可对同一条指令各自回应；
    未命中本插件命令的消息直接跳过，完全不影响其它插件处理普通聊天。
    """
    return match_command(event) is not None


anime_wife_matcher = on_message(
    rule=Rule(_trigger_rule),
    priority=plugin_config.command_priority,
    block=plugin_config.block_other_plugins,
)


@anime_wife_matcher.handle()
async def handle_wife_command(matcher: Matcher, bot: Bot, event: Event) -> None:
    """消息分发处理（仅群聊监听）

    bot / event 通过依赖注入获取：NoneBot2 2.5 起 Matcher 不再暴露
    ``matcher.bot`` / ``matcher.event`` 属性。
    """
    cmd = match_command(event)
    if cmd is None:
        return

    await anime_wife.commands[cmd](event, bot, matcher)


anime_wife.start()


@get_driver().on_shutdown
async def _() -> None:
    await anime_wife.shutdown()