"""插件配置（Lite 版：不含牛老婆相关功能）。

配置来源与优先级（从低到高）：

1. 类内默认值
2. NoneBot2 插件配置机制 ``get_plugin_config``（NoneBot2 >= 2.2）
3. ``.env`` 中的 ``ANIMEWIFEX_LITE_*``
4. 系统环境变量中的 ``ANIMEWIFEX_LITE_*``

配置前缀与数据目录均与完整版（``nonebot_plugin_animewifex``）相互隔离，
两个版本可以同时存在于同一个 NoneBot2 实例而不互相污染数据。

之所以额外实现前缀读取：NoneBot2 的 ``get_plugin_config`` 按字段名
直接读取环境变量（如 ``DATA_DIR``），既没有插件前缀，也会被全局配置同名项干扰。
这里显式按前缀读取，保证「插件配置只影响插件」，且行为不随 NoneBot2 版本变化。
"""

from __future__ import annotations

import json
import os
from typing import Any

from nonebot import get_driver, logger
from pydantic import BaseModel

ENV_PREFIX = "ANIMEWIFEX_LITE_"


class Config(BaseModel):
    """二次元老婆 Lite 版插件配置

    仅保留「抽老婆 / 查老婆 / 换老婆」三个玩法所需的配置项，
    交换、重置、管理员相关配置已随对应功能一并移除。
    """

    need_prefix: bool = False
    """启用触发前缀：开启后需要使用命令前缀（如 ``/抽老婆``）才能触发"""

    change_max_per_day: int = 3
    """每天最多更换老婆的次数"""

    image_base_url: str = "https://cdn.jsdmirror.com/gh/monbed/wife@main"
    """图片服务器基础 URL，用于拼接图片链接"""

    image_list_url: str = "https://animewife.dpdns.org/list.txt"
    """图片列表 URL，用于获取图片文件名列表"""

    timezone: str = ""
    """判定「今天」使用的 IANA 时区，留空则使用 NoneBot2 全局 ``TZ``，再回退 Asia/Shanghai"""

    command_priority: int = 0
    """事件响应器优先级，数值越小越先执行。

    本插件靠优先级抢在通用 ``on_message`` 插件之前处理自己的命令：
    默认 0，可抢在 ``nonebot_plugin_today_waifu`` 等同样注册了「换老婆」的插件之前。
    若调到比对方还大，而对方是 ``block=True``，本插件就收不到事件了，所以建议保持小值。
    """

    block_other_plugins: bool = False
    """是否独占本插件的命令（``block=True``）

    默认 ``false``：答完之后放行，其它老婆插件仍可对同一条指令各自回应。
    设为 ``true`` 则拦截后续插件，同一条指令只由本插件回答。
    """

    data_dir: str = ""
    """插件数据目录，留空则使用 NoneBot2 的 ``<data_dir>/animewifex_lite``"""


def _model_fields() -> dict[str, Any]:
    """兼容 pydantic v1 / v2 的字段表"""
    fields = getattr(Config, "model_fields", None)
    return fields if fields is not None else Config.__fields__


def _raw_values() -> dict[str, str]:
    """读取 .env 文件与系统环境变量，环境变量优先"""
    values: dict[str, str] = {}
    try:
        from dotenv import dotenv_values

        env_files = getattr(get_driver().config, "_env_file", None) or (".env",)
        if isinstance(env_files, (str, os.PathLike)):
            env_files = (env_files,)
        for file in env_files:
            try:
                values.update(
                    {k: v for k, v in dotenv_values(file).items() if v is not None}
                )
            except Exception:
                # .env 不存在或不可读时忽略
                pass
    except ImportError:  # pragma: no cover - nonebot 依赖 python-dotenv
        pass
    values.update(os.environ)
    return values


def _parse_value(annotation: Any, raw: str) -> Any:
    """按字段类型解析字符串，复杂类型（列表等）按 JSON 解析"""
    origin = getattr(annotation, "__origin__", None)
    is_complex = origin in (list, set, tuple, dict) or (
        isinstance(annotation, type) and issubclass(annotation, BaseModel)
    )
    value = json.loads(raw) if is_complex else raw
    try:
        from pydantic import TypeAdapter

        return TypeAdapter(annotation).validate_python(value)
    except ImportError:  # pragma: no cover - pydantic v1
        from pydantic import parse_obj_as

        return parse_obj_as(annotation, value)


def _base_config() -> Config:
    """NoneBot2 >= 2.2 走官方插件配置机制，旧版本退回默认值"""
    try:
        from nonebot import get_plugin_config  # type: ignore[attr-defined]

        return get_plugin_config(Config)
    except ImportError:  # pragma: no cover - NoneBot2 2.0 / 2.1
        pass
    except Exception:
        logger.warning("读取 NoneBot2 插件配置失败，改用默认配置")
    try:
        return Config(**get_driver().config.dict())
    except Exception:
        return Config()


def _load_config() -> Config:
    config = _base_config()
    raw_values = _raw_values()

    updates: dict[str, Any] = {}
    for name, field in _model_fields().items():
        raw = raw_values.get(f"{ENV_PREFIX}{name.upper()}")
        if raw is None or not str(raw).strip():
            continue
        annotation = getattr(field, "annotation", None) or getattr(
            field, "outer_type_", str
        )
        try:
            updates[name] = _parse_value(annotation, raw)
        except Exception:
            logger.warning(f"插件配置 {ENV_PREFIX}{name.upper()} 解析失败，已忽略: {raw!r}")

    if not updates:
        return config
    # pydantic v1 是 copy，v2 是 model_copy
    copier = getattr(config, "model_copy", None) or config.copy
    return copier(update=updates)


plugin_config = _load_config()