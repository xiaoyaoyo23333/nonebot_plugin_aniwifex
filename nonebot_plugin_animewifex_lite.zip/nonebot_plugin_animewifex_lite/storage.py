"""二次元老婆插件的持久化与数据校验工具。

本模块与 AstrBot 版 ``main.py`` 中的同名函数保持一致：
原子写入、结构损坏降级、旧格式迁移，保证两端数据文件可互换。
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from nonebot import logger

# IANA 时区数据由 requirements.txt 声明的 tzdata 保证
DEFAULT_TIMEZONE = "Asia/Shanghai"


def get_today(tz: ZoneInfo) -> str:
    """获取指定时区的当前日期字符串"""
    return datetime.now(tz).date().isoformat()


def seconds_until_next_midnight(tz: ZoneInfo) -> float:
    """距指定时区下一个零点的秒数"""
    now = datetime.now(tz)
    next_midnight = datetime.combine(
        (now + timedelta(days=1)).date(), datetime.min.time(), tzinfo=tz
    )
    return (next_midnight - now).total_seconds()


def load_json(path: str | Path) -> dict:
    """安全加载 JSON 文件"""
    path = Path(path)
    if not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, UnicodeDecodeError):
        logger.error(f"JSON 文件解析失败，可能已损坏，将以空数据载入: {path}")
        return {}
    except OSError:
        logger.error(f"读取 JSON 文件失败，将以空数据载入: {path}")
        return {}
    if not isinstance(data, dict):
        logger.error(f"JSON 文件顶层不是字典，可能被外部修改，将以空数据载入: {path}")
        return {}
    return data


def save_json(path: str | Path, data: dict) -> None:
    """原子方式保存 JSON 文件：先写临时文件再替换，避免写入中断导致文件损坏

    注意：函数内不能引入 await 点，全程同步执行才能保证
    不同群锁下的并发协程不会交错写同一文件。
    """
    path = Path(path)
    tmp_path = Path(f"{path}.tmp")
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        os.replace(tmp_path, path)
    except Exception:
        logger.exception(f"保存 JSON 文件失败: {path}")
        if tmp_path.exists():
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        raise


def sanitize_group_records(data: Any, desc: str) -> dict:
    """校验 {群: {用户: 记录字典}} 两层嵌套结构，被外部改坏的非法条目记 error 后丢弃

    load_json 只保证顶层是字典；内层结构损坏若不在加载时过滤，
    会在启动清理或命令处理中抛 AttributeError 导致插件加载失败。
    """
    if data is None:
        return {}
    if not isinstance(data, dict):
        logger.error(f"{desc} 不是字典，可能被外部修改，已丢弃")
        return {}
    cleaned = {}
    for gid, grp in data.items():
        if not isinstance(grp, dict):
            logger.error(f"{desc} 中群 {gid} 的数据不是字典，可能被外部修改，已丢弃")
            continue
        for uid, rec in grp.items():
            if not isinstance(rec, dict):
                logger.error(
                    f"{desc} 中群 {gid} 用户 {uid} 的记录不是字典，可能被外部修改，已丢弃"
                )
        cleaned[gid] = {uid: rec for uid, rec in grp.items() if isinstance(rec, dict)}
    return cleaned


def migrate_wife_data(data: Any) -> dict | None:
    """老婆数据统一为 {"img", "date", "owner"} 字典；旧版位置列表自动迁移，无法识别返回 None"""
    if isinstance(data, dict) and "img" in data:
        return data
    if isinstance(data, list) and len(data) >= 3:
        return {"img": data[0], "date": data[1], "owner": data[2]}
    return None


def has_today_wife(cfg: dict, uid: str, today: str) -> bool:
    """判断用户在群配置中是否拥有今天的老婆"""
    wife = cfg.get(uid)
    return isinstance(wife, dict) and wife.get("date") == today