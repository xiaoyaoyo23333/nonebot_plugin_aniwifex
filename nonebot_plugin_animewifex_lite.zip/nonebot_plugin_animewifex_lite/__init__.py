"""二次元老婆 Lite（NoneBot2 版）

完整版 `nonebot_plugin_animewifex` 的**最小精简分支**：只保留「抽老婆 / 查老婆 / 换老婆」
三个玩法，适合只需要每日抽老婆、玩腻了其它玩法的群。

Lite 版移除了：

- **命令**：``牛老婆``、``重置牛``、``切换ntr开关状态``、``重置换``、
  ``交换老婆``、``同意交换``、``拒绝交换``、``查看交换请求``
- **配置**：``ntr_max``、``ntr_possibility``、``swap_max_per_day``、
  ``reset_max_uses_per_day``、``reset_success_rate``、``reset_mute_duration``、``admins``
- **数据**：``records.json`` 中的 ``ntr`` / ``reset`` / ``swap`` 分区、``ntr_status.json``、
  ``swap_requests.json``

保留命令共 4 条：``老婆帮助``、``抽老婆``、``查老婆``、``换老婆``。

配置前缀与数据目录独立（``ANIMEWIFEX_LITE_`` / ``animewifex_lite``），
可与完整版共存互不干扰。

由 AstrBot 插件 `astrbot_plugin_animewifex` 移植而来，业务逻辑、数据格式与
持久化方式保持一致，仅替换框架相关 API：

============================  ==========================================
AstrBot                        NoneBot2
============================  ==========================================
``AstrBotConfig``              ``get_plugin_config(Config)``
``StarTools.get_data_dir``     配置项 ``data_dir`` / NoneBot2 ``data_dir``
``Star`` + ``terminate``       模块导入即初始化 + ``driver.on_shutdown``
``AstrMessageEvent``           ``Event`` / ``Matcher``
``At`` / ``Plain`` / ``Image``  ``MessageSegment.at/text/image``
``filter.event_message_type``  ``on_message`` + 群聊过滤
``event.is_at_or_wake_command``  ``COMMAND_START`` 前缀匹配（``need_prefix``）
============================  ==========================================

注册方式（二者任选）::

    nb-cli plugin install ./nonebot_plugin_animewifex_lite

或把整个目录放进 ``src/plugins/animewifex_lite/`` 后启动 NoneBot2。
"""

from __future__ import annotations

import asyncio
import os
import random
import time
from collections.abc import Awaitable, Callable
from datetime import timedelta, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import aiohttp
from nonebot import get_driver, logger, on_message
from nonebot.adapters import Bot, Event, Message, MessageSegment
from nonebot.matcher import Matcher
from nonebot.rule import Rule

from .config import Config, plugin_config
from .storage import (
    DEFAULT_TIMEZONE,
    get_today,
    has_today_wife,
    load_json,
    migrate_wife_data,
    sanitize_group_records,
    save_json,
    seconds_until_next_midnight,
)

# ==================== 框架适配层 ====================

__all__ = [
    "AnimeWife",
    "Config",
    "anime_wife",
    "anime_wife_matcher",
    "match_command",
    "plugin_config",
]


def _session_type(event: Event) -> str | None:
    """获取会话类型

    NoneBot2 2.5 移除了 ``Event.get_session_type()``，改为直接读取适配器提供的
    ``message_type`` 字段（OneBot V11 / V12 均为 ``group`` / ``private``）；
    旧版本优先走 ``get_session_type()``，都没有时按 ``group_id`` 兜底。
    """
    getter = getattr(event, "get_session_type", None)
    if callable(getter):
        try:
            return str(getter())
        except Exception:
            pass
    message_type = getattr(event, "message_type", None)
    if isinstance(message_type, str):
        return message_type
    if getattr(event, "group_id", None) is not None:
        return "group"
    return None


def _is_group_event(event: Event) -> bool:
    """判断是否为群聊消息事件"""
    return _session_type(event) == "group"


def _bot_self_id(bot: Bot) -> str:
    """机器人自身账号（NoneBot2 2.5 起 Event 不再提供 get_self_id）"""
    return str(getattr(bot, "self_id", "") or "")


def _seg_cls(event: Event) -> type:
    """获取事件使用的消息段类型

    NoneBot2 2.5 起 text()/at()/image() 等工厂方法只存在于各适配器的
    MessageSegment 子类上，核心基类不再提供，这里统一从事件取当前适配器的段类型。
    """
    try:
        return event.get_message().get_segment_class()
    except Exception:
        return MessageSegment


def _event_user_name(event: Event) -> str:
    """获取发送者昵称

    NoneBot2 2.5 移除了 ``Event.get_user_name()``，此处按适配器字段逐级回退：
    OneBot V11 的 ``sender.card`` / ``sender.nickname``，
    OneBot V12 的 ``member.card`` / ``user.display_name``。
    """
    getter = getattr(event, "get_user_name", None)
    if callable(getter):
        try:
            name = getter()
            if name:
                return str(name).strip()
        except Exception:
            pass
    for container_name in ("sender", "member", "user"):
        container = getattr(event, container_name, None)
        if container is None:
            continue
        for key in ("card", "display_name", "nickname", "name"):
            value = getattr(container, key, None)
            if value:
                return str(value).strip()
    for key in ("nickname", "name"):
        value = getattr(event, key, None)
        if value:
            return str(value).strip()
    return ""


def _command_prefixes() -> tuple[str, ...]:
    """读取 NoneBot2 全局命令前缀配置（.env 中的 COMMAND_START）"""
    try:
        raw = get_driver().config.command_start
    except Exception:
        raw = ("/",)
    if isinstance(raw, str):
        raw = (raw,)
    return tuple(str(p) for p in raw if p)


def _extract_text(event: Event) -> str:
    """提取用于命令匹配的消息文本

    ``get_plaintext()`` 会自动剔除 @ 等非文本消息段，因此 ``@机器人 抽老婆``
    与 ``抽老婆`` 等价，AstrBot 版的「唤醒」语义天然保留。

    ``need_prefix`` 开启时要求以 COMMAND_START 中的前缀开头，并去掉该前缀；
    若 COMMAND_START 含空字符串（默认「所有消息都是命令」）则前缀模式不可用。
    """
    try:
        text = event.get_plaintext().strip()
    except Exception:
        return ""
    if not text or not plugin_config.need_prefix:
        return text
    for prefix in _command_prefixes():
        if text.startswith(prefix):
            return text[len(prefix) :].lstrip()
    return ""


def _parse_at_target(event: Event, self_id: str) -> str | None:
    """解析消息中的 @ 目标用户

    跳过所有指向机器人自身的 At，返回第一个有效的目标用户 ID；未找到时返回 None。
    """
    try:
        segments = event.get_message()
    except Exception:
        return None
    for seg in segments:
        if getattr(seg, "type", None) != "at":
            continue
        data = getattr(seg, "data", None)
        if not isinstance(data, dict):
            continue
        uid = data.get("qq") or data.get("user_id")
        if uid is None:
            continue
        uid = str(uid)
        if uid and uid != self_id:
            return uid
    return None


def _build_message(event: Event, segments: list[MessageSegment]) -> Message:
    """用事件自带的消息类组装消息，保证与适配器的类型一致"""
    try:
        message_cls: type[Message] = type(event.get_message())
    except Exception:
        message_cls = Message
    return message_cls(segments)


def _text_seg(event: Event, text: str) -> MessageSegment:
    """构建文本消息段"""
    seg_cls = _seg_cls(event)
    factory = getattr(seg_cls, "text", None)
    if callable(factory):
        try:
            return factory(text)
        except Exception:
            pass
    return seg_cls("text", {"text": text})


def _at_seg(event: Event, user_id: str) -> MessageSegment:
    """构建 @ 消息段"""
    seg_cls = _seg_cls(event)
    factory = getattr(seg_cls, "at", None)
    if callable(factory):
        try:
            return factory(user_id)
        except Exception:
            pass
    return seg_cls("at", {"qq": str(user_id)})


def _image_seg(
    event: Event, *, file: str | None = None, url: str | None = None
) -> MessageSegment:
    """构建图片消息段（本地文件优先用适配器的 image()，远程链接走 url 字段）"""
    seg_cls = _seg_cls(event)
    if file:
        factory = getattr(seg_cls, "image", None)
        if callable(factory):
            try:
                return factory(file)
            except Exception:
                pass
        return seg_cls("image", {"file": str(file)})
    return seg_cls("image", {"url": url})


# ==================== 主插件逻辑 ====================


class AnimeWife:
    """二次元老婆插件主类（原 AstrBot ``WifePlugin``）"""

    def __init__(self) -> None:
        self._init_config()
        self._init_commands()
        self._init_storage()
        self._daily_cleanup_task: asyncio.Task | None = None

    # ==================== 初始化 ====================

    def _init_config(self) -> None:
        """初始化配置参数（带默认值兜底，避免配置缺项导致加载失败）"""
        self.tz = self._resolve_timezone()
        self.need_prefix = bool(plugin_config.need_prefix)
        self.change_max_per_day = plugin_config.change_max_per_day
        base_url = (
            plugin_config.image_base_url
            or "https://cdn.jsdmirror.com/gh/monbed/wife@main"
        )
        self.image_base_url = base_url.rstrip("/") + "/"
        self.image_list_url = (
            plugin_config.image_list_url or "https://animewife.dpdns.org/list.txt"
        )

    def _resolve_timezone(self) -> ZoneInfo:
        """解析判定「今天」所用的时区

        优先级：``ANIMEWIFEX_TIMEZONE`` > NoneBot2 全局 ``timezone`` > 环境变量 ``TZ``
        > ``Asia/Shanghai``。

        Windows 的 Python 默认不带 IANA 时区库（NoneBot2 也不依赖 ``tzdata``），
        此时 ``ZoneInfo`` 会抛 ``ZoneInfoNotFoundError``；这里逐个候选尝试，
        全部失败后退回固定 UTC+8，保证插件始终能正常加载，不会因缺少可选依赖而崩溃。
        """
        candidates: list[str] = []
        tz_name = str(plugin_config.timezone or "").strip()
        if tz_name:
            candidates.append(tz_name)
        try:
            global_tz = str(getattr(get_driver().config, "timezone", "") or "").strip()
        except Exception:
            global_tz = ""
        if global_tz:
            candidates.append(global_tz)
        env_tz = os.environ.get("TZ", "").strip()
        if env_tz:
            candidates.append(env_tz)
        candidates.append(DEFAULT_TIMEZONE)

        for name in candidates:
            try:
                return ZoneInfo(name)
            except Exception:
                logger.error(f"时区 {name!r} 不可用，尝试下一个回退值")

        # 连 tzdata 都没装时的最终兜底：东八区固定偏移
        logger.warning(
            "未找到可用的 IANA 时区数据（是否缺少 tzdata？），已回退固定 UTC+8"
        )
        return timezone(timedelta(hours=8))  # type: ignore[return-value]

    def _resolve_data_dir(self) -> Path:
        """插件数据目录

        优先 ``ANIMEWIFEX_LITE_DATA_DIR``；其次 NoneBot2 全局 ``data_dir/animewifex_lite``；
        全局也未配置时退回项目目录下约定俗成的 ``data/animewifex_lite``。
        """
        raw = str(plugin_config.data_dir or "").strip()
        if raw:
            path = Path(raw).expanduser()
            return path if path.is_absolute() else Path.cwd() / path
        try:
            base = str(getattr(get_driver().config, "data_dir", "") or "").strip()
        except Exception:
            base = ""
        if not base:
            base = "data"  # NoneBot2 历史默认的数据目录
        path = Path(base).expanduser()
        if not path.is_absolute():
            path = Path.cwd() / path
        return path / "animewifex_lite"

    def _init_commands(self) -> None:
        """初始化命令映射表"""
        self.commands: dict[str, Callable[[Event, Bot, Matcher], Awaitable[None]]] = {
            "老婆帮助": self.wife_help,
            "抽老婆": self.animewife,
            "查老婆": self.search_wife,
            "换老婆": self.change_wife,
        }
        # 按命令名长度降序排列，匹配时避免较短的命令意外截胡更长的命令
        self.command_names = sorted(self.commands, key=len, reverse=True)

    def _init_storage(self) -> None:
        """初始化数据目录并加载持久化数据"""
        plugin_dir = self._resolve_data_dir()
        self.config_dir = plugin_dir / "config"
        self.img_dir = plugin_dir / "img" / "wife"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.img_dir.mkdir(parents=True, exist_ok=True)

        self.records_file = self.config_dir / "records.json"
        self.wife_list_cache_file = self.config_dir / "wife_list_cache.txt"

        # 群组级状态锁：保护该群的老婆配置与次数记录
        self.group_locks: dict[str, asyncio.Lock] = {}

        raw = load_json(self.records_file)
        # change=换老婆次数
        self.records = {
            key: sanitize_group_records(raw.get(key), f"records.json[{key}]")
            for key in ("change",)
        }
        # 启动阶段尚无并发，清理无需加锁；校验丢弃过非法条目时同样需要落盘
        today = get_today(self.tz)
        changed = any(self.records[key] != raw.get(key, {}) for key in self.records)
        for gid in {gid for recs in self.records.values() for gid in recs}:
            changed |= self._prune_group_records(gid, today)
        if changed:
            self.save_records()

    # ==================== 并发与持久化 ====================

    def get_group_lock(self, group_id: str) -> asyncio.Lock:
        """获取或创建群组级状态锁"""
        if group_id not in self.group_locks:
            self.group_locks[group_id] = asyncio.Lock()
        return self.group_locks[group_id]

    def save_records(self) -> None:
        save_json(self.records_file, self.records)

    def _prune_group_records(self, gid: str, today: str) -> bool:
        """删除某群各类别中日期不是今天的次数记录，群内清空后移除该群条目，返回是否有变动

        处理协程可能在群锁内持有群记录字典的引用跨越 await 点，
        运行期调用必须先持有该群的锁，避免删除群条目后协程写入悬空字典。
        """
        changed = False
        for recs in self.records.values():
            grp = recs.get(gid)
            if grp is None:
                continue
            stale = [uid for uid, rec in grp.items() if rec.get("date") != today]
            for uid in stale:
                del grp[uid]
            if stale or not grp:
                changed = True
            if not grp:
                del recs[gid]
        return changed

    def load_group_config(self, group_id: str) -> dict:
        """加载群组配置，旧版列表格式的老婆数据自动迁移为字典，无法识别的条目丢弃"""
        raw = load_json(self.config_dir / f"{group_id}.json")
        cfg = {}
        for uid, data in raw.items():
            wife = migrate_wife_data(data)
            if wife is not None:
                cfg[uid] = wife
        return cfg

    def save_group_config(self, group_id: str, cfg: dict) -> None:
        save_json(self.config_dir / f"{group_id}.json", cfg)

    # ==================== 通用辅助 ====================

    @staticmethod
    def _uid(event: Event) -> str:
        return str(event.get_user_id())

    @staticmethod
    def _gid(event: Event) -> str:
        return str(getattr(event, "group_id"))

    @staticmethod
    def _nick(event: Event) -> str:
        return _event_user_name(event) or str(event.get_user_id())

    async def _send_all(self, matcher: Matcher, replies: list[Any]) -> None:
        """依次发送收集好的回复"""
        for reply in replies:
            await matcher.send(reply)

    # ==================== 目标解析 ====================

    def parse_target(self, event: Event, text: str, bot: Bot) -> str | None:
        """解析命令目标用户：优先 @ ，其次「查老婆 昵称」形式的昵称匹配"""
        target = _parse_at_target(event, _bot_self_id(bot))
        if target:
            return target

        if text.startswith("查老婆"):
            parts = text.split(maxsplit=1)
            if len(parts) > 1:
                name = parts[1]
                cfg = self.load_group_config(self._gid(event))
                for uid, wife in cfg.items():
                    if wife.get("owner") == name:
                        return uid
        return None

    # ==================== 抽老婆与查询 ====================

    async def animewife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """抽老婆"""
        gid = self._gid(event)
        uid = self._uid(event)
        nick = self._nick(event)
        today = get_today(self.tz)

        async with self.get_group_lock(gid):
            cfg = self.load_group_config(gid)
            if not has_today_wife(cfg, uid, today):
                img = await self._fetch_wife_image()
                if img:
                    cfg[uid] = {"img": img, "date": today, "owner": nick}
                    self.save_group_config(gid, cfg)
            else:
                img = cfg[uid]["img"]

        if not img:
            await matcher.finish("抱歉，今天的老婆获取失败了，请稍后再试~")
        await matcher.finish(self._build_wife_message(event, img, nick))

    async def search_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """查老婆"""
        gid = self._gid(event)
        text = _extract_text(event)
        tid = self.parse_target(event, text, bot) or self._uid(event)
        today = get_today(self.tz)

        cfg = self.load_group_config(gid)

        if not has_today_wife(cfg, tid, today):
            await matcher.finish("没有发现老婆的踪迹，快去抽一个试试吧~")

        img = cfg[tid]["img"]
        owner = cfg[tid].get("owner", "未知用户")
        chara, source = self._parse_wife_name(img)
        if source:
            text_out = f"{owner}的老婆是来自《{source}》的{chara}，羡慕吗？"
        else:
            text_out = f"{owner}的老婆是{chara}，羡慕吗？"
        await matcher.finish(self._build_chain(event, text_out, img))

    async def _fetch_wife_image(self) -> str | None:
        """获取老婆图片，依次尝试：本地图库 → 有效缓存 → 网络列表 → 过期缓存兜底"""
        try:
            with os.scandir(self.img_dir) as entries:
                local_imgs = [e.name for e in entries if e.is_file()]
            if local_imgs:
                return random.choice(local_imgs)
        except OSError:
            pass

        cached_lines: list[str] = []
        cache_expired = True
        if self.wife_list_cache_file.exists():
            try:
                cache_expired = (
                    time.time() - self.wife_list_cache_file.stat().st_mtime
                ) >= 3600
                with open(self.wife_list_cache_file, "r", encoding="utf-8") as f:
                    cached_lines = [
                        s for s in (line.strip() for line in f.read().splitlines()) if s
                    ]
            except (OSError, UnicodeDecodeError):
                pass

        if not cache_expired and cached_lines:
            return random.choice(cached_lines)

        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(self.image_list_url) as resp:
                    if resp.status == 200:
                        text = await resp.text()
                        lines = [
                            s for s in (line.strip() for line in text.splitlines()) if s
                        ]
                        if lines:
                            # 缓存写入失败不影响本次结果
                            try:
                                with open(
                                    self.wife_list_cache_file, "w", encoding="utf-8"
                                ) as f:
                                    f.write("\n".join(lines))
                            except OSError:
                                pass
                            return random.choice(lines)
        except Exception:
            pass

        if cached_lines:
            return random.choice(cached_lines)

        return None

    @staticmethod
    def _parse_wife_name(img: str) -> tuple[str, str | None]:
        """从图片标识解析出 (角色名, 作品来源)，无来源时来源为 None"""
        name = os.path.splitext(img)[0].split("/")[-1]
        if "!" in name:
            source, chara = name.split("!", 1)
            return chara, source
        return name, None

    def _build_image_segment(self, event: Event, img: str) -> MessageSegment | None:
        """根据图片标识构建图片消息段（本地优先，回退到 URL）"""
        # 图片标识来自远程列表，本地读取前校验路径未逃逸出图库目录
        local_path: str | None = None
        try:
            base = os.path.abspath(self.img_dir)
            path = os.path.abspath(os.path.join(base, img))
            # Windows 下跨盘符会让 commonpath 抛 ValueError，此时按「不在图库内」处理，
            # 直接回退到 URL，而不是丢掉整张图片
            contained = os.path.commonpath([base, path]) == base
            if contained and os.path.isfile(path):
                local_path = path
        except (ValueError, OSError):
            local_path = None

        try:
            if local_path:
                return _image_seg(event, file=local_path)
            return _image_seg(event, url=self.image_base_url + img)
        except Exception:
            logger.exception("构建图片消息段失败")
            return None

    def _build_chain(self, event: Event, text: str, img: str) -> Message:
        """构建「文字 + 图片」消息，图片段构建失败时仅保留文字"""
        parts = [_text_seg(event, text)]
        img_seg = self._build_image_segment(event, img)
        if img_seg is not None:
            parts.append(img_seg)
        return _build_message(event, parts)

    def _build_wife_message(self, event: Event, img: str, nick: str) -> Message:
        """构建「你今天的老婆是…」消息"""
        chara, source = self._parse_wife_name(img)
        if source:
            text = f"{nick}，你今天的老婆是来自《{source}》的{chara}，请好好珍惜哦~"
        else:
            text = f"{nick}，你今天的老婆是{chara}，请好好珍惜哦~"
        return self._build_chain(event, text, img)

    # ==================== 帮助命令 ====================

    async def wife_help(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """显示帮助信息"""
        help_text = """
【基础命令】
• 抽老婆 - 每天抽取一个二次元老婆
• 查老婆 [@用户] - 查看别人的老婆

【换老婆功能】
• 换老婆 - 丢弃当前老婆换新的

💡 提示：换老婆有每日使用次数限制
"""
        await matcher.finish(help_text.strip())

    # ==================== 换老婆相关 ====================

    async def change_wife(self, event: Event, bot: Bot, matcher: Matcher) -> None:
        """换老婆"""
        gid = self._gid(event)
        uid = self._uid(event)
        nick = self._nick(event)
        today = get_today(self.tz)

        replies: list[Any] = []
        # 次数检查、自增与更换老婆在同一临界区内完成，避免并发绕过每日上限
        async with self.get_group_lock(gid):
            recs = self.records["change"].setdefault(gid, {})
            rec = recs.get(uid, {"date": "", "count": 0})

            cfg = self.load_group_config(gid)
            if rec["date"] == today and rec["count"] >= self.change_max_per_day:
                replies.append(
                    f"{nick}，你今天已经换了{self.change_max_per_day}次老婆啦，明天再来吧~"
                )
            elif not has_today_wife(cfg, uid, today):
                replies.append(f"{nick}，你今天还没有老婆，先去抽一个再来换吧~")
            else:
                # 先抽到新老婆再替换；抽取失败时老婆和次数都保持不动
                img = await self._fetch_wife_image()
                if not img:
                    replies.append(
                        "抱歉，新老婆获取失败了，本次更换未生效，请稍后再试~"
                    )
                else:
                    cfg[uid] = {"img": img, "date": today, "owner": nick}
                    self.save_group_config(gid, cfg)

                    if rec["date"] != today:
                        rec = {"date": today, "count": 1}
                    else:
                        rec["count"] += 1
                    recs[uid] = rec
                    self.save_records()

                    replies.append(self._build_wife_message(event, img, nick))

        await self._send_all(matcher, replies)

    # ==================== 定时清理 ====================

    async def _daily_cleanup_loop(self) -> None:
        """每天零点清理跨天失效的历史次数记录"""
        while True:
            try:
                # 多等一分钟，避免时钟误差导致在日期变更前执行
                await asyncio.sleep(seconds_until_next_midnight(self.tz) + 60)
                await self._cleanup_expired_records()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("定时清理过期数据失败")

    async def _cleanup_expired_records(self) -> None:
        """逐群清理历史次数记录（在群锁内执行，避免与处理协程交错）"""
        today = get_today(self.tz)
        changed = False
        for gid in {gid for recs in self.records.values() for gid in recs}:
            async with self.get_group_lock(gid):
                if self._prune_group_records(gid, today):
                    changed = True
        if changed:
            self.save_records()

    def start(self) -> None:
        """插件加载后启动零点清理任务"""
        if self._daily_cleanup_task and not self._daily_cleanup_task.done():
            return
        coro = self._daily_cleanup_loop()
        try:
            self._daily_cleanup_task = asyncio.create_task(coro)
        except RuntimeError:
            # 无运行中的事件循环时关闭协程，避免 "coroutine never awaited" 告警
            coro.close()
            self._daily_cleanup_task = None

    async def shutdown(self) -> None:
        """NoneBot2 关闭 / 插件卸载时停止后台任务（对应 AstrBot 的 terminate）"""
        task = self._daily_cleanup_task
        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass


# ==================== 插件注册 ====================

anime_wife = AnimeWife()


def match_command(event: Event) -> str | None:
    """返回消息命中的本插件命令名，未命中返回 None

    同时供匹配规则与处理函数使用，避免两处判定逻辑走偏。
    """
    if not _is_group_event(event):
        return None
    text = _extract_text(event)
    if not text:
        return None
    for cmd in anime_wife.command_names:
        if text.startswith(cmd):
            return cmd
    return None


def _trigger_rule(event: Event) -> bool:
    """只在群聊、且消息以本插件命令开头时触发

    配合 ``block=False``（默认）实现「各答各的」：本插件答完之后放行事件，
    其它老婆插件仍可对同一条指令各自回应；未命中本插件命令的消息直接跳过，
    完全不影响其它插件处理普通聊天。
    """
    return match_command(event) is not None


anime_wife_matcher = on_message(
    rule=Rule(_trigger_rule),
    priority=plugin_config.command_priority,
    block=plugin_config.block_other_plugins,
)


@anime_wife_matcher.handle()
async def handle_wife_command(matcher: Matcher, bot: Bot, event: Event) -> None:
    """消息分发处理（仅群聊监听）

    bot / event 通过依赖注入获取：NoneBot2 2.5 起 Matcher 不再暴露
    ``matcher.bot`` / ``matcher.event`` 属性。
    """
    cmd = match_command(event)
    if cmd is None:
        return

    await anime_wife.commands[cmd](event, bot, matcher)


anime_wife.start()


@get_driver().on_shutdown
async def _() -> None:
    await anime_wife.shutdown()
