# nonebot_plugin_animewifex_lite

二次元老婆插件的 **Lite 版**，由 AstrBot 插件
[astrbot_plugin_animewifex](https://github.com/monbed/astrbot_plugin_animewifex) 移植而来。

**只保留 4 条命令**：`老婆帮助` / `抽老婆` / `查老婆` / `换老婆`。
适合只需要「每天抽个老婆、抽腻了换一个」的群，功能越少越不容易打架。

## 与完整版的关系

| | 完整版 | Lite 版（本插件） |
| --- | --- | --- |
| 包名 | `nonebot_plugin_animewifex` | `nonebot_plugin_animewifex_lite` |
| 配置前缀 | `ANIMEWIFEX_` | `ANIMEWIFEX_LITE_` |
| 默认数据目录 | `data/animewifex` | `data/animewifex_lite` |
| 指令数 | 13 | **4** |

配置前缀与数据目录完全隔离，两者可以同时装在一个 NoneBot2 实例里而不互相污染。
但两者**指令名完全相同**，默认会各答一遍——同一实例里请**只启用其中一个**，
或给其中一个设 `ANIMEWIFEX_BLOCK_OTHER_PLUGINS=true` 让它独占。

Lite 版相对完整版移除了：

- **命令**：`牛老婆`、`重置牛`、`切换ntr开关状态`、`重置换`、
  `交换老婆`、`同意交换`、`拒绝交换`、`查看交换请求`
- **配置**：`ntr_max`、`ntr_possibility`、`swap_max_per_day`、
  `reset_max_uses_per_day`、`reset_success_rate`、`reset_mute_duration`、`admins`
- **数据**：`records.json` 中的 `ntr` / `reset` / `swap` 分区、
  `ntr_status.json`、`swap_requests.json`

> 因此 Lite 版**不会调用禁言 API**，也不需要配置管理员 QQ。

> 与**其它老婆插件**（如抽群友的 `today_waifu`）则可以共存，见下方
> 「与其它老婆插件共存」。

## 安装

```bash
nb-cli plugin install ./nonebot_plugin_animewifex_lite
```

或直接把整个目录复制到 `src/plugins/animewifex_lite/` 后启动 NoneBot2。

依赖：

- `aiohttp` —— NoneBot2 本身已依赖，通常无需处理。
- `tzdata` —— **Windows 上建议安装**（见下方「Windows 注意事项」）。不装也能运行，
  插件会自动回退到固定 UTC+8。安装方式：`pip install tzdata`。

## 已验证的运行环境

| NoneBot2 | OneBot 适配器 | pydantic | 结果 |
| --- | --- | --- | --- |
| 2.4.2 | 2.4.6 | 2.13 | ✅ 全部功能测试通过 |
| 2.4.2 | 2.4.3 | 2.13 | ✅ 全部功能测试通过 |
| 2.4.2 | 无 tzdata（Windows 默认状态） | 2.13 | ✅ 全部功能测试通过 |
| 2.5.0 | 2.4.6 | 2.13 | ✅ 全部功能测试通过 |

Windows 11 23H2 + Python 3.11.9 实测无差异：插件源码按 Python 3.9+ 语法编写。

## Windows 注意事项

1. **时区数据（tzdata）**：Windows 的 Python 默认不带 IANA 时区库，NoneBot2 也不依赖
   `tzdata`。未安装时插件不会崩溃，会退化为固定 UTC+8——默认时区本就是东八区，
   「今天」的判断依然正确；但若把 `ANIMEWIFEX_LITE_TIMEZONE` 改成带夏令时的时区，
   请务必 `pip install tzdata`。也可用环境变量 `TZ=Asia/Shanghai` 指定。

2. **数据目录是相对路径**：默认的 `data/animewifex_lite` 相对于 **NoneBot2 的启动目录（CWD）**。
   用计划任务 / NSSM / 快捷方式启动且 CWD 不是项目根目录时，数据会落到别处，
   建议显式指定：`ANIMEWIFEX_LITE_DATA_DIR=D:/nonebot-bot/data/animewifex_lite`。

3. **本地图库文件名**：支持中文与 `!`、`空格` 等字符（`作品名!角色名.jpg`）。

## 配置

在 `.env` 或系统环境变量中配置，前缀为 `ANIMEWIFEX_LITE_`：

```dotenv
ANIMEWIFEX_LITE_NEED_PREFIX=false          # 是否需要命令前缀触发
ANIMEWIFEX_LITE_CHANGE_MAX_PER_DAY=3       # 每日换老婆次数（唯一的功能性配置）
# ANIMEWIFEX_LITE_IMAGE_BASE_URL=          # 已停用：远程图床，插件只读本地图库
# ANIMEWIFEX_LITE_IMAGE_LIST_URL=          # 已停用：远程图片列表
ANIMEWIFEX_LITE_TIMEZONE=Asia/Shanghai     # 判定「今天」用的时区；留空依次回退 NoneBot2 timezone、TZ、Asia/Shanghai
ANIMEWIFEX_LITE_COMMAND_PRIORITY=0         # 匹配器优先级，越小越先执行（见下方「与其它老婆插件共存」）
ANIMEWIFEX_LITE_BLOCK_OTHER_PLUGINS=false  # true=独占本插件命令；false=其它老婆插件仍可各自回应
ANIMEWIFEX_LITE_DATA_DIR=                  # 数据目录，留空则用 <data_dir>/animewifex_lite
```

> 配置优先级：默认值 < NoneBot2 插件配置机制 < `.env` 的 `ANIMEWIFEX_LITE_*`
> < 环境变量的 `ANIMEWIFEX_LITE_*`。显式实现前缀读取是因为 NoneBot2 的
> `get_plugin_config` 按字段名直接读环境变量（如 `DATA_DIR`），既没有插件前缀，
> 也会被全局同名配置项干扰。

只剩一个可调的功能性参数：

| 想要的效果 | 配置 |
| --- | --- |
| 让人多换几次 | `ANIMEWIFEX_LITE_CHANGE_MAX_PER_DAY=10` |
| 几乎不让换 | `ANIMEWIFEX_LITE_CHANGE_MAX_PER_DAY=0`（抽完就锁死） |
| 抽不到图时手动补图 | 往 `<数据目录>/img/wife/` 放 `作品名!角色名.jpg`，本地图库优先级最高 |

## 图片来源：本地图库

插件为**纯本地模式**，不请求任何远程图床：

- 图片只从 `<数据目录>/img/wife/` 读取
- `ANIMEWIFEX_LITE_IMAGE_BASE_URL` / `ANIMEWIFEX_LITE_IMAGE_LIST_URL` 已**停用**（代码中已注释），
  写在 `.env` 里也不会再生效
- 图库为空时会记录一条 warning 并回复「获取失败」，不会去联网兜底

放图方式（文件名按 `作品名!角色名.jpg` 命名，`!` 前会被当作作品来源显示）：

```text
data/animewifex_lite/img/wife/
├── 轻小说!明日香.jpg
├── 英雄联盟!阿卡丽.jpg
└── 明日香.jpg      ← 没有 ! 的也能用，只是文案不报作品
```

> 若想恢复远程图床：取消 `__init__.py` 中 `_fetch_wife_image` 注释掉的取图段、
> `_build_image_segment` 的 URL 回退分支、`_init_config` 里的图床配置，
> 以及 `config.py` 中的 `image_base_url` / `image_list_url` 字段与 `aiohttp` 依赖。

> **前缀触发**：把 `ANIMEWIFEX_LITE_NEED_PREFIX` 设为 `true` 后，命令必须以
> `COMMAND_START` 中的前缀开头（如 `/抽老婆`）。若 `.env` 里的 `COMMAND_START`
> 含空字符串，前缀模式不会生效，请先去掉空字符串。

## 功能与用法

群聊每天重置的玩法，4 条命令，**仅在群聊生效**，私聊不触发。

### 指令匹配规则（严格匹配）

命令必须是**整条消息**（去掉 @ 等非文本段后）：

| 消息 | 是否响应 |
| --- | --- |
| `换老婆` / `抽老婆` / `老婆帮助` | ✅ |
| `查老婆 明日香` / `查老婆 @某人` | ✅ |
| `帮我换老婆` / `换老婆啊` / `xxxx换老婆xxxx` / `抽老婆抽老婆` | ❌ 不响应 |
| `换老婆。` / `换老婆~` | ❌ 不响应 |

即：**只接受「命令」本身，或「命令 + 空格 + 参数」**。聊天里随口提到「换老婆」
不会再误触发，也不会和别的插件抢消息。

> 开了 `ANIMEWIFEX_LITE_NEED_PREFIX` 时，前缀会被先剥掉再按同样的规则匹配。

### 指令速查

| 指令 | 作用 | 限制 |
| --- | --- | --- |
| `老婆帮助` | 列出全部命令 | — |
| `抽老婆` | 抽今天的老婆 | 每天一次，当天不再变 |
| `查老婆 [@用户]` / `查老婆 昵称` | 查自己或别人的老婆 | — |
| `换老婆` | 丢弃当前老婆重抽 | 每天 3 次，需已有老婆 |

### 抽老婆 / 查老婆

```
小明：抽老婆
Bot ：小明，你今天的老婆是来自《轻小说》的明日香，请好好珍惜哦~ [图片]
```

之后一整天再发 `抽老婆`，返回的是同一个人（幂等）。

```
小明：查老婆
Bot ：小明的老婆是来自《轻小说》的明日香，羡慕吗？ [图片]

小明：查老婆 @小红
Bot ：小红的老婆是来自《单作者》的凉宫，羡慕吗？ [图片]

小明：查老婆 凉宫          ← 不 @ 也可以，昵称匹配
Bot ：小明的老婆是来自《单作者》的凉宫，羡慕吗？ [图片]
```

> **图片名决定文案**：文件名按 `作品名!角色名.jpg` 命名，`!` 前当作作品来源；
> 没有 `!` 就只报角色名。

### 换老婆

```
小明：换老婆
Bot ：小明，你今天的老婆是来自《相合之物》的雪平一果，请好好珍惜哦~ [图片]
```

- 当天还没抽过老婆会被拦：`小明，你今天还没有老婆，先去抽一个再来换吧~`
- 用完次数：`小明，你今天已经换了3次老婆啦，明天再来吧~`
- 抽取失败时老婆和次数都保持不动，不会白扣次数。

## 与其它老婆插件共存

完整版、或 `nonebot_plugin_today_waifu` 之类的「今日老婆」插件，往往也注册了
`抽老婆` / `换老婆`，而 `on_message` 默认 `block=True`——**谁先匹配到，事件就不再往下传**，
排在后面的插件会「静默无响应」，日志里只能看到
`Event will be handled by Matcher(... module=别的插件 ...)`。

本插件的做法是**只认自己的命令，答完放行**：

| 配置项 | 默认 | 作用 |
| --- | --- | --- |
| `ANIMEWIFEX_LITE_COMMAND_PRIORITY` | `0` | 排在通用 `on_message` 插件之前，避免被对方 `block` 吞掉 |
| `ANIMEWIFEX_LITE_BLOCK_OTHER_PLUGINS` | `false` | 答完后**放行**，对方插件仍可对同一条指令各自回应 |
| 匹配器 `rule` | — | 仅消息以本插件命令开头时触发，不响应普通聊天 |

默认状态可与其它老婆插件共存，各答各的；想让二次元老婆独占，把
`ANIMEWIFEX_LITE_BLOCK_OTHER_PLUGINS` 设为 `true` 即可。

> ⚠️ 别把优先级调大：对方若是 `block=True` 且优先级更低，你就收不到事件了。
> 配置在插件加载时读取，**修改后需重启 NoneBot2**。

## 常见排查

| 现象 | 处理 |
| --- | --- |
| 插件加载报错 / 时区相关异常 | `pip install tzdata`（Windows 上必需） |
| 数据好像清零了 | 检查 NoneBot2 的启动 CWD，建议 `ANIMEWIFEX_LITE_DATA_DIR` 写绝对路径 |
| 抽不出图 | 看日志有无拉取失败；先往 `img/wife/` 放两张本地图验证链路 |
| 指令没反应 | 必须在群里发（私聊不触发）；若开了 `NEED_PREFIX`，得用 `/抽老婆` |
| 某条命令单独没反应、日志显示 `module=` 别的插件 | 优先级被对方 `block` 抢走，保持 `ANIMEWIFEX_LITE_COMMAND_PRIORITY=0`（默认）即可 |
| 同一个指令被回了两次 | 想独占就设 `ANIMEWIFEX_LITE_BLOCK_OTHER_PLUGINS=true`；想共存保持默认 |
| 完整版和 Lite 版同时启用 | **指令名相同，必须只启用一个**，否则会各答一遍 |
| 机器人不再禁言了 | Lite 版已移除重置玩法，本就不含禁言逻辑，属正常 |

## 数据存储

数据目录默认为 `<NoneBot2 data_dir>/animewifex_lite`（全局 `data_dir` 未配置时为
`<项目目录>/data/animewifex_lite`），可用 `ANIMEWIFEX_LITE_DATA_DIR` 覆盖：

```text
animewifex_lite/
├── config/
│   ├── <群号>.json          # 该群成员的老婆记录
│   ├── records.json         # 每日换老婆次数记录（仅 change 一个分区）
│   └── wife_list_cache.txt  # 图片列表缓存（1 小时）
└── img/wife/                # 本地图库（可手动放图）
```

Lite 版**不会**生成 `ntr_status.json` 和 `swap_requests.json`，
`records.json` 里也只有 `change` 一个分区。

JSON 均为原子写入（临时文件 + 替换），并对文件被外部改坏的情况做了降级处理；
每天零点后自动清理过期的次数记录。

## 兼容性

插件通过「能力探测 + 逐级回退」的方式编写，不绑定任何特定 NoneBot2 / 适配器版本：

| 能力 | 处理方式 |
| --- | --- |
| bot / event 获取 | 一律用依赖注入（`bot: Bot, event: Event`），不碰 `matcher.bot` / `matcher.event`——后者在 2.4+ 已不存在 |
| 机器人自身账号 | `bot.self_id`，不依赖 `Event.get_self_id()`（2.4+ 已移除） |
| 群聊判定 | `get_session_type()` → 事件 `message_type` 字段 → `group_id` 属性 |
| 发送者昵称 | `get_user_name()` → `sender.card` / `sender.nickname` → `member.card` / `user.display_name` |
| 消息段构造 | 从事件取适配器的消息段类再调其 `text()` / `at()` / `image()`，缺失则按标准字段直接构造 |
| @ 目标解析 | 按 `segment.type == "at"` + `data["qq"]` 解析，不使用适配器特有的 `is_at()` |
| pydantic | 同时兼容 v1（`__fields__` / `parse_obj_as` / `.copy()`）与 v2（`model_fields` / `TypeAdapter` / `.model_copy()`） |

经实测：**NoneBot2 2.4.2 与 2.5.0 的核心 `Event` / `Matcher` / `MessageSegment` API 形状完全一致**，
因此当前实现对两个版本通用；更早的 2.2 / 2.3 因保留了这些便捷方法，会走回退链的第一级，同样可用。

## 与 AstrBot 版的差异

- 事件监听由 `@filter.event_message_type(GROUP_MESSAGE)` 改为带 `rule` 的 `on_message`：
  只在消息以本插件命令开头时触发，答完默认放行（`block=False`），可与其它老婆插件共存，
  见上方「与其它老婆插件共存」。
- 「触发前缀」由 NoneBot2 的 `COMMAND_START` 实现。
- 时区改读 `ANIMEWIFEX_LITE_TIMEZONE`（回退到 NoneBot2 的 `timezone`、`TZ` 环境变量，
  最后回退 `Asia/Shanghai`）。
- 牛老婆、交换、重置相关的一切（命令、配置、数据、昵称匹配、禁言调用）已从 Lite 版移除。